
package cliente;
public class MainCliente {
  public static void main(String[] args){ javax.swing.SwingUtilities.invokeLater(()-> new InterfazCajero().setVisible(true)); }
}
